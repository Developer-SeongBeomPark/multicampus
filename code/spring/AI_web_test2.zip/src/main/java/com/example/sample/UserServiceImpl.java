package com.example.sample;

public class UserServiceImpl implements UserService {

}
