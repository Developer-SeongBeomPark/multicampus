package com.example.sample;

public interface UserService {

}
