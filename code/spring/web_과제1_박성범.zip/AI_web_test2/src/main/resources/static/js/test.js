$(function(){
	$("#login_btn").click(function(){
		let id = document.getElementById("id").value;
		let pw = document.getElementById("pw").value;
		alert(id + pw);
		
	});
});

