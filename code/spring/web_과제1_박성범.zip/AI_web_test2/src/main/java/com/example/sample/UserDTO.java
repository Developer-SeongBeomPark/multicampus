package com.example.sample;

public class UserDTO {
  
  
}
