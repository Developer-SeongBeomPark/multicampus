package com.example.sample;


public interface UserMapper {


}
